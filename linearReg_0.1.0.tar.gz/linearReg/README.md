# LinearReg Package

<!-- badges: start -->
[![Codecov test coverage](https://codecov.io/gh/xinjinli2/bios625_hw3/branch/main/graph/badge.svg)](https://app.codecov.io/gh/xinjinli2/bios625_hw3?branch=main)
[![R-CMD-check](https://github.com/xinjinli2/bios625_hw3/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/xinjinli2/bios625_hw3/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->
